package jschulz;

/**
 * Cipher
 */
public interface Cipher {
    public String encrypt(String input);
    public String decrypt(String input);
}
